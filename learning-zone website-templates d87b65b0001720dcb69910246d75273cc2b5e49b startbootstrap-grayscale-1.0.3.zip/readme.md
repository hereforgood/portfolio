## Project Description

* [live example](https://learning-zone.github.io/website-templates/startbootstrap-grayscale-1.0.3)

![alt text](https://github.com/learning-zone/website-templates/blob/master/assets/startbootstrap-grayscale-1.0.3.png "startbootstrap-grayscale-1.0.3")
